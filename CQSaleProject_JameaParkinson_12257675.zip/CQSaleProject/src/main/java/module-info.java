module com.mycompany.cqsaleproject {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.mycompany.cqsaleproject to javafx.fxml;
    exports com.mycompany.cqsaleproject;
}
